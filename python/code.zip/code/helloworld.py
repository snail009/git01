#！/usr/bin/env ptyhon
print("hello world!")