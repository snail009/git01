#!/usr/bin/env python
# -*- coding:utf-8 -*-
#Author:freeman

name = "freeman"
print("my name is ",name,"how are you!")
print(type(name))