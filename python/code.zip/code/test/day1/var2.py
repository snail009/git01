#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:freeman

name = "freeman"
name2 = name
print("my name is ", name, "how are you!", name2)
print(type(name))

name = 'jack'
print(name, name2)

name3 = 'snail'
print(name3)

# 复杂变量命名方式
Gf_of_oldboy = "xiaohong"          #下划线
GFOfOldboy = "xiaoming"            #开头字母大写

#python 常量定义方式
PIE = "123"            #python一般通过大写来定义

print(PIE)

str = "2**8你好"
print(str)



#注释    三个单引号或是双引号
msg = '''
hello,world!  
你好，世界！'''

print(msg)
