#!/usr/bin/env python
# -*- coding:utf-8 -*-
#Author:freeman
print("hello world")



'''
import keyword,sys
print(keyword.kwlist)
print(sys.path)
'''

#input("\n\n按下 enter 键后退出。")



'''
for n in range(2, 10):
    for x in range(2, n):
        if n % x == 0:
            print(n, '等于', x, '*', n//x)
            break
    else:
        # 循环中没有找到元素
        print(n, ' 是质数')
'''

#msg = "我爱北京"
#print(msg.encode(encoding="utf-8"))
#print(msg.encode(encoding="utf-8").decode())

