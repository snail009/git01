#!/usr/bin/env python
# -*- coding:utf-8 -*-
#Author:freeman

#name = "free\tman"
name2 = 'mynameisfreemanandiamteold'
'''
print(name.capitalize())
print(name.count('e'))
print(name.center(50,"-"))
print(name.endswith("an"))
print(name.expandtabs(30))
'''
print(name2.find("s"))
print(name2[name2.find("s"):])
print(name2.format(name="freeman",year=22))
print(name2.isalnum())
print(name2.isalpha())
print('_2'.isidentifier())
print('',)