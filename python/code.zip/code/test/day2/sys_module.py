#!/usr/bin/env python
# -*- coding:utf-8 -*-
#Author:freeman

import sys

#sys.path 一些相关库文件路径，注意命名文件名不能是系统定义的模块名称
print(sys.path)

#
print(sys.argv)
print(sys.argv[2])

